import 'package:flutter/material.dart';

class PlayList extends StatefulWidget {
  PlayList({Key? key}) : super(key: key);

  @override
  State<PlayList> createState() => _PlayListState();
}

class _PlayListState extends State<PlayList> {
  @override
  Widget build(BuildContext context) {
    return Container(
        height: double.infinity,
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
              colors: [Color(0xFFDD4C4C), Color.fromARGB(255, 255, 255, 255)],
              stops: [0.5, 1],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter),
        ),
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              elevation: 0,
              backgroundColor: Colors.transparent,
              title: Text(
                'Playlist',
                style: TextStyle(color: Colors.black),
              ),
              centerTitle: true,
            ),
            body: Padding(
              padding: const EdgeInsets.all(30),
              child: SafeArea(
                child: Column(
                  children: [
                    Text(
                      'Sorry no play list',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
            floatingActionButton: SizedBox(
              height: 100,
              //width: 60,
              child: FloatingActionButton(
                child: Icon(Icons.add),
                onPressed: () {
                  showDialog(
                      context: context, builder: (ctxt) => creatPlaylist());
                },
                backgroundColor: Colors.red,
              ),
            ),
          ),
        ));
  }

  Widget creatPlaylist() {
    return Container(
        child: AlertDialog(
      title: Text('Playlist Name'),
      content: TextFormField(
        decoration: InputDecoration(hintText: 'Name required'),
      ),
      actions: [
        TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('Cancel')),
        TextButton(onPressed: () {}, child: Text('Save')),
      ],
      elevation: 0,
      backgroundColor: Color.fromARGB(255, 227, 220, 220),
    ));
  }
}
